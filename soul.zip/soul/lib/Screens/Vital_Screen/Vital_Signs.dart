import 'package:soul/Components/text_field_container.dart';
import 'package:intl/intl.dart';
import 'package:flutter/material.dart';
import 'package:soul/constants.dart';
import 'package:soul/Components/rounded_input_field.dart';
import 'package:soul/Components/addButton.dart';
import 'package:soul/Components/background.dart';

class Vitals extends StatefulWidget {
  @override
  _VitalsState createState() => _VitalsState();
}

class _VitalsState extends State<Vitals> {
  DateTime _date;
  @override
  Widget build(BuildContext context) {
    return Background(
      title: 'Add Vital Signs',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            height: 20.0,
          ),
          _textLabel('Temperature'),
          RoundedInputField(
            icon: null,
          ),
          _textLabel('Blood Pressure'),
          RoundedInputField(
            icon: null,
          ),
          _textLabel('Pulse'),
          RoundedInputField(
            icon: null,
          ),
          _textLabel('Height'),
          RoundedInputField(
            icon: null,
          ),
          _textLabel('Weight'),
          RoundedInputField(
            icon: null,
          ),
          _textLabel('Blood Type'),
          RoundedInputField(
            icon: null,
          ),
          _textLabel('Time'),
          RoundedInputField(
            icon: null,
          ),
          _textLabel('Date'),
          TextFieldContainer(
            child: TextField(
              cursorColor: kPrimaryColor,
              decoration: InputDecoration(
                hintText: _date == null
                    ? ''
                    : DateFormat('dd-MM-yyyy').format(_date),
                suffixIcon: IconButton(
                    icon: Icon(
                      Icons.date_range_rounded,
                      color: kPrimaryLightColor,
                    ),
                    onPressed: () {
                      showDatePicker(
                        context: context,
                        initialDate: DateTime.now(), // Current Date
                        firstDate: DateTime(1900), // First date
                        lastDate: DateTime(2200), // Last Date
                        builder: (BuildContext context, Widget child) {
                          return Theme(
                              data: ThemeData(
                                primarySwatch:
                                txtColor, // Color of Ok and Cancel
                                primaryColor:
                                kPrimaryColor, // Select date color
                                accentColor: kPrimaryColor, // Select date color
                              ),
                              child: child);
                        },
                      ).then((date) {
                        setState(() {
                          _date = date;
                        });
                      });
                    }),
                border: InputBorder.none,
              ),
            ),
          ),
          Center(
            child: AddButton(
              text: 'Add',
            ),
          ),
          SizedBox(
            height: 20.0,
          )
        ],
      ),
    );
  }

  Widget _textLabel(String label) => Text(label,
      textAlign: TextAlign.start,
      style: TextStyle(fontSize: 18.0, color: kPrimaryLightColor));
}
