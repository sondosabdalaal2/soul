import 'package:flutter/material.dart';
import 'package:soul/constants.dart';
import 'package:soul/Components/addButton.dart';
import 'package:soul/Components/background.dart';
import 'package:flutter/cupertino.dart';
import 'package:soul/Components/rounded_input_field.dart';

class MedicalHistory extends StatefulWidget {
  @override
  _MedicalHistoryState createState() => _MedicalHistoryState();
}

class _MedicalHistoryState extends State<MedicalHistory> {
  bool _val = false, _val2 = false, _val3 = false, _val4 = false;

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Background(
      title: 'Add Medical History',
      child: SingleChildScrollView(
        child: Column(
          //shrinkWrap:true,
         // scrollDirection: Axis.vertical,
          children: [
            SizedBox(
              height: 20.0,
            ),
            CheckboxListTile(
                value: _val,
                title: Align(
                    alignment: Alignment.centerLeft,
                    child: Text('Chronic Disease')),
                onChanged: (bool newVal) {
                  setState(() {
                    _val = newVal;
                  });
                }),
            _val
                ? Container(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            SizedBox(
                              width: 40.0,
                            ),
                            _textLabel('Disease Name'),
                          ],
                        ),
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            SizedBox(
                              width: 45.0,
                            ),
                            Container(
                                margin: EdgeInsets.symmetric(vertical: 10),
                                padding: EdgeInsets.symmetric(
                                    horizontal: 20, vertical: 5),
                                width: size.width * .5,
                                height: 40.0,
                                decoration: BoxDecoration(
                                    color: Colors.white,
                                    boxShadow: [
                                      BoxShadow(
                                          color: Colors.grey,
                                          blurRadius: 2.0,
                                          spreadRadius: 0.4)
                                    ],
                                    shape: BoxShape.rectangle
                                    //borderRadius: BorderRadius.circular(29),
                                    ),
                                child: TextField()),
                          ],
                        ),
                        Row(
                          children: [
                            SizedBox(
                              width: 40.0,
                            ),
                            _textLabel('Medicine'),
                          ],
                        ),
                        Row(
                          children: [
                            SizedBox(
                              width: 45.0,
                            ),
                            Container(
                                margin: EdgeInsets.symmetric(vertical: 10),
                                padding: EdgeInsets.symmetric(
                                    horizontal: 20, vertical: 5),
                                width: size.width * .5,
                                height: 40.0,
                                decoration: BoxDecoration(
                                    color: Colors.white,
                                    boxShadow: [
                                      BoxShadow(
                                          color: Colors.grey,
                                          blurRadius: 2.0,
                                          spreadRadius: 0.4)
                                    ],
                                    shape: BoxShape.rectangle
                                    //borderRadius: BorderRadius.circular(29),
                                    ),
                                child: TextField()),
                          ],
                        ),
                        Row(
                          children: [
                            SizedBox(
                              width: 40.0,
                            ),
                            _textLabel('Duration'),
                          ],
                        ),
                        Row(
                          children: [
                            SizedBox(
                              width: 45.0,
                            ),
                            Container(
                                margin: EdgeInsets.symmetric(vertical: 10),
                                padding: EdgeInsets.symmetric(
                                    horizontal: 20, vertical: 5),
                                width: size.width * .5,
                                height: 40.0,
                                decoration: BoxDecoration(
                                    color: Colors.white,
                                    boxShadow: [
                                      BoxShadow(
                                          color: Colors.grey,
                                          blurRadius: 2.0,
                                          spreadRadius: 0.4)
                                    ],
                                    shape: BoxShape.rectangle
                                    //borderRadius: BorderRadius.circular(29),
                                    ),
                                child: TextField()),
                          ],
                        ),
                      ],
                    ),
                  )
                : Container(),
            CheckboxListTile(
                value: _val2,
                title: Align(
                    alignment: Alignment.centerLeft,
                    child: Text('Genetic Disease')),
                onChanged: (bool newVal) {
                  setState(() {
                    _val2 = newVal;
                  });
                }),
            _val2
                ? Container(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      SizedBox(
                        width: 40.0,
                      ),
                      _textLabel('Disease Name'),
                    ],
                  ),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      SizedBox(
                        width: 45.0,
                      ),
                      Container(
                          margin: EdgeInsets.symmetric(vertical: 10),
                          padding: EdgeInsets.symmetric(
                              horizontal: 20, vertical: 5),
                          width: size.width * .5,
                          height: 40.0,
                          decoration: BoxDecoration(
                              color: Colors.white,
                              boxShadow: [
                                BoxShadow(
                                    color: Colors.grey,
                                    blurRadius: 2.0,
                                    spreadRadius: 0.4)
                              ],
                              shape: BoxShape.rectangle
                            //borderRadius: BorderRadius.circular(29),
                          ),
                          child: TextField()),
                    ],
                  ),
                  Row(
                    children: [
                      SizedBox(
                        width: 40.0,
                      ),
                      _textLabel('Medicine'),
                    ],
                  ),
                  Row(
                    children: [
                      SizedBox(
                        width: 45.0,
                      ),
                      Container(
                          margin: EdgeInsets.symmetric(vertical: 10),
                          padding: EdgeInsets.symmetric(
                              horizontal: 20, vertical: 5),
                          width: size.width * .5,
                          height: 40.0,
                          decoration: BoxDecoration(
                              color: Colors.white,
                              boxShadow: [
                                BoxShadow(
                                    color: Colors.grey,
                                    blurRadius: 2.0,
                                    spreadRadius: 0.4)
                              ],
                              shape: BoxShape.rectangle
                            //borderRadius: BorderRadius.circular(29),
                          ),
                          child: TextField()),
                    ],
                  ),
                  Row(
                    children: [
                      SizedBox(
                        width: 40.0,
                      ),
                      _textLabel('Duration'),
                    ],
                  ),
                  Row(
                    children: [
                      SizedBox(
                        width: 45.0,
                      ),
                      Container(
                          margin: EdgeInsets.symmetric(vertical: 10),
                          padding: EdgeInsets.symmetric(
                              horizontal: 20, vertical: 5),
                          width: size.width * .5,
                          height: 40.0,
                          decoration: BoxDecoration(
                              color: Colors.white,
                              boxShadow: [
                                BoxShadow(
                                    color: Colors.grey,
                                    blurRadius: 2.0,
                                    spreadRadius: 0.4)
                              ],
                              shape: BoxShape.rectangle
                            //borderRadius: BorderRadius.circular(29),
                          ),
                          child: TextField()),
                    ],
                  ),
                ],
              ),
            )
                : Container(),
            CheckboxListTile(
                value: _val3,
                title: Align(
                    alignment: Alignment.centerLeft,
                    child: Text('Have an operation')),
                onChanged: (bool newVal) {
                  setState(() {
                    _val3 = newVal;
                  });
                }),
            _val3
                ? Container(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      SizedBox(
                        width: 40.0,
                      ),
                      _textLabel('Operation Name'),
                    ],
                  ),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      SizedBox(
                        width: 45.0,
                      ),
                      Container(
                          margin: EdgeInsets.symmetric(vertical: 10),
                          padding: EdgeInsets.symmetric(
                              horizontal: 20, vertical: 5),
                          width: size.width * .5,
                          height: 40.0,
                          decoration: BoxDecoration(
                              color: Colors.white,
                              boxShadow: [
                                BoxShadow(
                                    color: Colors.grey,
                                    blurRadius: 2.0,
                                    spreadRadius: 0.4)
                              ],
                              shape: BoxShape.rectangle
                            //borderRadius: BorderRadius.circular(29),
                          ),
                          child: TextField()),
                    ],
                  ),
                  Row(
                    children: [
                      SizedBox(
                        width: 40.0,
                      ),
                      _textLabel('When'),
                    ],
                  ),
                  Row(
                    children: [
                      SizedBox(
                        width: 45.0,
                      ),
                      Container(
                          margin: EdgeInsets.symmetric(vertical: 10),
                          padding: EdgeInsets.symmetric(
                              horizontal: 20, vertical: 5),
                          width: size.width * .5,
                          height: 40.0,
                          decoration: BoxDecoration(
                              color: Colors.white,
                              boxShadow: [
                                BoxShadow(
                                    color: Colors.grey,
                                    blurRadius: 2.0,
                                    spreadRadius: 0.4)
                              ],
                              shape: BoxShape.rectangle
                            //borderRadius: BorderRadius.circular(29),
                          ),
                          child: TextField()),
                    ],
                  ),
                  Row(
                    children: [
                      SizedBox(
                        width: 40.0,
                      ),
                      _textLabel('Hospital Name'),
                    ],
                  ),
                  Row(
                    children: [
                      SizedBox(
                        width: 45.0,
                      ),
                      Container(
                          margin: EdgeInsets.symmetric(vertical: 10),
                          padding: EdgeInsets.symmetric(
                              horizontal: 20, vertical: 5),
                          width: size.width * .5,
                          height: 40.0,
                          decoration: BoxDecoration(
                              color: Colors.white,
                              boxShadow: [
                                BoxShadow(
                                    color: Colors.grey,
                                    blurRadius: 2.0,
                                    spreadRadius: 0.4)
                              ],
                              shape: BoxShape.rectangle
                            //borderRadius: BorderRadius.circular(29),
                          ),
                          child: TextField()),
                    ],
                  ),
                  Row(
                    children: [
                      SizedBox(
                        width: 40.0,
                      ),
                      _textLabel('Doctor Name'),
                    ],
                  ),
                  Row(
                    children: [
                      SizedBox(
                        width: 45.0,
                      ),
                      Container(
                          margin: EdgeInsets.symmetric(vertical: 10),
                          padding: EdgeInsets.symmetric(
                              horizontal: 20, vertical: 5),
                          width: size.width * .5,
                          height: 40.0,
                          decoration: BoxDecoration(
                              color: Colors.white,
                              boxShadow: [
                                BoxShadow(
                                    color: Colors.grey,
                                    blurRadius: 2.0,
                                    spreadRadius: 0.4)
                              ],
                              shape: BoxShape.rectangle
                            //borderRadius: BorderRadius.circular(29),
                          ),
                          child: TextField()),
                    ],
                  ),
                  Row(
                    children: [
                      SizedBox(
                        width: 40.0,
                      ),
                      _textLabel('Doctor Phone'),
                    ],
                  ),
                  Row(
                    children: [
                      SizedBox(
                        width: 45.0,
                      ),
                      Container(
                          margin: EdgeInsets.symmetric(vertical: 10),
                          padding: EdgeInsets.symmetric(
                              horizontal: 20, vertical: 5),
                          width: size.width * .5,
                          height: 40.0,
                          decoration: BoxDecoration(
                              color: Colors.white,
                              boxShadow: [
                                BoxShadow(
                                    color: Colors.grey,
                                    blurRadius: 2.0,
                                    spreadRadius: 0.4)
                              ],
                              shape: BoxShape.rectangle
                            //borderRadius: BorderRadius.circular(29),
                          ),
                          child: TextField()),
                    ],
                  ),
                ],
              ),
            )
                : Container(),
            CheckboxListTile(
                value: _val4,
                title: Align(
                    alignment: Alignment.centerLeft,
                    child: Text('Have an accident')),
                onChanged: (bool newVal) {
                  setState(() {
                    _val4 = newVal;
                  });
                }),
            _val4
                ? Container(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      SizedBox(
                        width: 40.0,
                      ),
                      _textLabel('Injury Type'),
                    ],
                  ),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      SizedBox(
                        width: 45.0,
                      ),
                      Container(
                          margin: EdgeInsets.symmetric(vertical: 10),
                          padding: EdgeInsets.symmetric(
                              horizontal: 20, vertical: 5),
                          width: size.width * .5,
                          height: 40.0,
                          decoration: BoxDecoration(
                              color: Colors.white,
                              boxShadow: [
                                BoxShadow(
                                    color: Colors.grey,
                                    blurRadius: 2.0,
                                    spreadRadius: 0.4)
                              ],
                              shape: BoxShape.rectangle
                            //borderRadius: BorderRadius.circular(29),
                          ),
                          child: TextField()),
                    ],
                  ),
                  Row(
                    children: [
                      SizedBox(
                        width: 40.0,
                      ),
                      _textLabel('When'),
                    ],
                  ),
                  Row(
                    children: [
                      SizedBox(
                        width: 45.0,
                      ),
                      Container(
                          margin: EdgeInsets.symmetric(vertical: 10),
                          padding: EdgeInsets.symmetric(
                              horizontal: 20, vertical: 5),
                          width: size.width * .5,
                          height: 40.0,
                          decoration: BoxDecoration(
                              color: Colors.white,
                              boxShadow: [
                                BoxShadow(
                                    color: Colors.grey,
                                    blurRadius: 2.0,
                                    spreadRadius: 0.4)
                              ],
                              shape: BoxShape.rectangle
                            //borderRadius: BorderRadius.circular(29),
                          ),
                          child: TextField()),
                    ],
                  ),

                ],
              ),
            )
                : Container(),
            Center(
              child: AddButton(
                text: 'Add',
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _textLabel(String label) => Text(label,
      textAlign: TextAlign.start,
      style: TextStyle(fontSize: 12.0, color: kPrimaryLightColor));
}
