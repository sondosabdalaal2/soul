import 'package:flutter/material.dart';
import 'package:soul/constants.dart';
import 'package:flutter/cupertino.dart';
import 'package:soul/Components/circular_image.dart';
class Profile extends StatefulWidget {
  @override
  _ProfileState createState() => _ProfileState();
}

class _ProfileState extends State<Profile> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: appbarWithBack(context, isProfileIconEnabled: false),
        backgroundColor: Colors.white,
        body: SafeArea(
          child: Container(
            padding: EdgeInsets.all(10),
            alignment: Alignment.topCenter,
            margin: EdgeInsets.fromLTRB(12, 0, 12, 0),
            child: SingleChildScrollView(
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    _firstSection(),
                    _informationSectionWithTitle("PERSONAL INFORMATION", [
                      _textFieldWithLabel("Birthday", "12/2/1999"),
                      _textFieldWithLabel("Language", "English"),
                      _textFieldWithLabel("Mobile Number", "+31454454545"),
                      _textFieldWithLabel('Email', 'my_email@example.com'),

                    ]),


                  ]),
            ),
          ),
        ));
  }

  Container _firstSection() => Container(
    padding: EdgeInsets.only(left: 20, right: 20, top: 30, bottom: 20),
    decoration: new BoxDecoration(
        color: Colors.white,
        borderRadius: new BorderRadius.all(new Radius.circular(10.0)),
        border: Border.all(
          color: Colors.black.withOpacity(0.1),
          width: 1.5,
        )),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        CirculerImage(imageName: 'profile.png',width: 140.0,height: 140.0,),
        SizedBox(
          height: 20,
        ),
        Text(
          "Kristen Jorge",
          style: TextStyle(
              fontSize: 30,
              color: kPrimarySecColor,
              fontWeight: FontWeight.bold),
        ),
        SizedBox(
          height: 5,
        ),
        SizedBox(
          height: 15,
        ),
        _highLightedSquares(),
      ],
    ),
  );


  Row _highLightedSquares() => Row(
    mainAxisAlignment: MainAxisAlignment.spaceAround,
    children: [
      _highlightedSquare("A+", "Blood"),
      _highlightedSquare("5ft", "Height"),
      _highlightedSquare("60kg", "Weight"),
    ],
  );

  Expanded _highlightedSquare(String title, String subtitle) => Expanded(
      child: Container(
        decoration: BoxDecoration(
          color: Colors.grey.withOpacity(0.1),
          borderRadius: new BorderRadius.all(new Radius.circular(5.0)),
        ),
        margin: EdgeInsets.all(5),
        padding: EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(title,
                style: TextStyle(
                    fontSize: 15,
                    color: kPrimarySecColor.withOpacity(1),
                    fontWeight: FontWeight.bold)),
            Text(subtitle,
                style: TextStyle(
                    fontSize: 12,
                    color: kPrimarySecColor.withOpacity(0.5),
                    fontWeight: FontWeight.bold))
          ],
        ),
      ));

  Container _informationSectionWithTitle(String title, List<Widget> children) =>
      Container(
        margin: EdgeInsets.only(top: 10),
        padding: EdgeInsets.only(left: 20, right: 20, top: 20, bottom: 15),
        decoration: new BoxDecoration(
            color: Colors.white,
            borderRadius: new BorderRadius.all(new Radius.circular(10.0)),
            border: Border.all(
              color: Colors.black.withOpacity(0.1),
              width: 1.5,
            )),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
                padding: EdgeInsets.only(bottom: 10, left: 5, top: 5),
                alignment: Alignment.topLeft,
                child: Text(title,
                    style: TextStyle(
                        color: kPrimarySecColor.withOpacity(0.9),
                        fontSize: 16,
                        fontWeight: FontWeight.w600))),
            ...children,
          ],
        ),
      );

  Widget _textFieldWithLabel(String label, String value) => Container(
      padding: EdgeInsets.only(left: 5, top: 10),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(
          label,
          textAlign: TextAlign.start,
          style: TextStyle(
              fontSize: 13.0,
              fontWeight: FontWeight.w600,
              color: Colors.grey.withOpacity(0.8)),
        ),
        _textField(value)
      ]));
  Widget appbarWithBack(BuildContext context,
      {bool isProfileIconEnabled = true}) {
    return AppBar(
      backgroundColor: Colors.white70,
      elevation: 0,
      leading: IconButton(
        icon: Icon(
          Icons.arrow_back_ios,
          color: kPrimarySecColor,
        ),
        onPressed: () => {Navigator.pop(context)},
      ),
      actions: <Widget>[
        isProfileIconEnabled
            ? IconButton(
          icon: Image.asset(
            'assets/images/profile.png',
            height: 25,
          ),
          onPressed: () => {context.navigateToScreen(Profile())},
        )
            : Container(),
        SizedBox(
          width: isProfileIconEnabled ? 8 : 0,
        ),
      ],
    );
  }
  TextFormField _textField(String value) => TextFormField(
      autofocus: false,
      initialValue: value,
      style: TextStyle(
          color: kPrimarySecColor.withOpacity(1),
          fontSize: 18,
          fontWeight: FontWeight.w600),
      decoration: new InputDecoration(
        border: InputBorder.none,
        focusedBorder: InputBorder.none,
        enabledBorder: InputBorder.none,
        errorBorder: InputBorder.none,
        disabledBorder: InputBorder.none,
        contentPadding: EdgeInsets.only(top: 0),
      ));
}
extension navigateScreen on BuildContext {
  navigateToScreen(StatefulWidget widget) {
    Navigator.of(this).push(CupertinoPageRoute(builder: (context) => widget));
  }
}