import 'package:flutter/material.dart';
import 'package:soul/constants.dart';
import 'package:soul/Components/rounded_input_field.dart';
import 'package:soul/Components/addButton.dart';
import 'package:soul/Components/background.dart';
import 'package:soul/Components/text_field_container.dart';
import 'package:intl/intl.dart';
class LabResult extends StatefulWidget {

  @override
  _LabResultState createState() => _LabResultState();
}

class _LabResultState extends State<LabResult> {
  DateTime _date;
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: kPrimaryColor,
        body: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: EdgeInsets.only(
                  top: 60.0, left: 30.0, right: 30.0, bottom: 30.0),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: <Widget>[
                  CircleAvatar(
                    radius: 15.0,
                    backgroundColor: Colors.white,
                    child: Icon(
                      Icons.add,
                      size: 30.0,
                      color: kPrimaryColor,
                    ),
                  ),
                  SizedBox(
                    width: 15.0,
                  ),
                  Expanded(
                    child: Text(
                      'Add Laboratory Result',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 30.0,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: Container(
                padding: EdgeInsets.symmetric(horizontal: 20.0),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(50.0),
                    topRight: Radius.circular(50.0),
                  ),
                ),
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(
                        height: 20.0,
                      ),
                      _textLabel('Test Name'),
                      RoundedInputField(
                        icon: null,
                      ),
                      _textLabel('Lab Name'),
                      RoundedInputField(
                        icon: null,
                      ),
                      _textLabel('Test Date'),
                      TextFieldContainer(
                        child: TextField(
                          cursorColor: kPrimaryColor,
                          decoration: InputDecoration(
                            hintText: _date == null
                                ? ''
                                : DateFormat('dd-MM-yyyy').format(_date),
                            suffixIcon: IconButton(
                                icon: Icon(
                                  Icons.date_range_rounded,
                                  color: kPrimaryLightColor,
                                ),
                                onPressed: () {
                                  showDatePicker(
                                    context: context,
                                    initialDate: DateTime.now(), // Current Date
                                    firstDate: DateTime(1900), // First date
                                    lastDate: DateTime(2200), // Last Date
                                    builder: (BuildContext context, Widget child) {
                                      return Theme(
                                          data: ThemeData(
                                            primarySwatch:
                                            txtColor, // Color of Ok and Cancel
                                            primaryColor:
                                            kPrimaryColor, // Select date color
                                            accentColor: kPrimaryColor, // Select date color
                                          ),
                                          child: child);
                                    },
                                  ).then((date) {
                                    setState(() {
                                      _date = date;
                                    });
                                  });
                                }),
                            border: InputBorder.none,
                          ),
                        ),
                      ),
                      Row(
                        children: [
                          _textLabel('Attach Report'),
                          Icon(Icons.attachment)
                        ],
                      ),
                      Center(
                        child: AddButton(
                          text: 'Add',
                        ),
                      ), SizedBox(height: 20.0,)
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),

      ),
    );
  }
  Widget _textLabel(String label) => Text(label,
      textAlign: TextAlign.start,
      style: TextStyle(fontSize: 18.0, color: kPrimaryLightColor));
}





