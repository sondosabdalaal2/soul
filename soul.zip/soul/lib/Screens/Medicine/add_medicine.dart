import 'package:flutter/material.dart';
import 'package:soul/constants.dart';
import 'package:soul/Components/rounded_input_field.dart';
import 'package:soul/Components/addButton.dart';
import 'package:soul/Components/background.dart';
import 'package:flutter/cupertino.dart';
import 'package:soul/Components/text_field_container.dart';
import 'package:intl/intl.dart';

class Medecine extends StatefulWidget {
  @override
  _MedecineState createState() => _MedecineState();
}

class _MedecineState extends State<Medecine> {
  DateTime _date;
  Duration initialtimer = new Duration();
  // Show the modal that contains the CupertinoDatePicker
  void _showDatePicker(ctx) {
    // showCupertinoModalPopup is a built-in function of the cupertino library
    showCupertinoModalPopup(
        context: ctx,
        builder: (_) => Container(
              height: 500,
              color: Color.fromARGB(255, 255, 255, 255),
              child: Column(
                children: [
                  Container(
                    height: 400,
                    child: CupertinoTimerPicker(
                      mode: CupertinoTimerPickerMode.hms,
                      minuteInterval: 1,
                      secondInterval: 1,
                      initialTimerDuration: initialtimer,
                      onTimerDurationChanged: (Duration changedtimer) {
                        setState(() {
                          initialtimer = changedtimer;
                        });
                      },
                    ),
                  ),

                  // Close the modal
                  CupertinoButton(
                    child: Text('OK'),
                    onPressed: () => Navigator.of(ctx).pop(),
                  )
                ],
              ),
            ));
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Background(
      title: 'Add Medicine Reminder',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            height: 20.0,
          ),
          _textLabel('Medicine Name'),
          RoundedInputField(
            icon: null,
          ),
          _textLabel('Number of doses'),
          RoundedInputField(
            icon: null,
          ),
          _textLabel('Time of first dose'),
          Container(
            child: CupertinoButton(
              padding: EdgeInsetsDirectional.zero,
              child: Center(
                child: Container(
                  margin: EdgeInsets.symmetric(vertical: 10),
                  padding: EdgeInsets.symmetric(horizontal: 20, vertical: 5),
                  height: size.height * 0.1,
                  width: size.width * 0.8,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    boxShadow: [
                      BoxShadow(
                          color: Colors.grey,
                          blurRadius: 2.0,
                          spreadRadius: 0.4)
                    ],
                    shape: BoxShape.rectangle,
                  ),
                  child: Center(
                    child: Text(
                      initialtimer != null
                          ? initialtimer.toString()
                          : 'No time picked!',
                      style: TextStyle(fontSize: 14.0, color: Colors.black),
                    ),
                  ),
                ),
              ),
              onPressed: () => _showDatePicker(context),
            ),
          ),
          _textLabel('Time among them'),
          Container(
            child: CupertinoButton(
              padding: EdgeInsetsDirectional.zero,
              child: Center(
                child: Container(
                  margin: EdgeInsets.symmetric(vertical: 10),
                  padding: EdgeInsets.symmetric(horizontal: 20, vertical: 5),
                  height: size.height * 0.1,
                  width: size.width * 0.8,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    boxShadow: [
                      BoxShadow(
                          color: Colors.grey,
                          blurRadius: 2.0,
                          spreadRadius: 0.4)
                    ],
                    shape: BoxShape.rectangle,
                  ),
                  child: Center(
                    child: Text(
                      initialtimer != null
                          ? initialtimer.toString()
                          : 'No time picked!',
                      style: TextStyle(fontSize: 14.0, color: Colors.black),
                    ),
                  ),
                ),
              ),
              onPressed: () => _showDatePicker(context),
            ),
          ),
          _textLabel('Start date'),
          TextFieldContainer(
            child: TextField(
              cursorColor: kPrimaryColor,
              decoration: InputDecoration(
                hintText: _date == null
                    ? 'Start day'
                    : DateFormat('dd-MM-yyyy').format(_date),
                suffixIcon: IconButton(
                    icon: Icon(
                      Icons.date_range_rounded,
                      color: kPrimaryLightColor,
                    ),
                    onPressed: () {
                      showDatePicker(
                        context: context,
                        initialDate: DateTime.now(), // Current Date
                        firstDate: DateTime(1900), // First date
                        lastDate: DateTime(2200), // Last Date
                        builder: (BuildContext context, Widget child) {
                          return Theme(
                              data: ThemeData(
                                primarySwatch:
                                    txtColor, // Color of Ok and Cancel
                                primaryColor:
                                    kPrimaryColor, // Select date color
                                accentColor: kPrimaryColor, // Select date color
                              ),
                              child: child);
                        },
                      ).then((date) {
                        setState(() {
                          _date = date;
                        });
                      });
                    }),
                border: InputBorder.none,
              ),
            ),
          ),
          _textLabel('End date'),
          TextFieldContainer(
            child: TextField(
              cursorColor: kPrimaryColor,
              decoration: InputDecoration(
                hintText: _date == null
                    ? 'End day'
                    : DateFormat('dd-MM-yyyy').format(_date),
                suffixIcon: IconButton(
                    icon: Icon(
                      Icons.date_range_rounded,
                      color: kPrimaryLightColor,
                    ),
                    onPressed: () {
                      showDatePicker(
                        context: context,
                        initialDate: DateTime.now(), // Current Date
                        firstDate: DateTime(1900), // First date
                        lastDate: DateTime(2200), // Last Date
                        builder: (BuildContext context, Widget child) {
                          return Theme(
                              data: ThemeData(
                                primarySwatch:
                                    txtColor, // Color of Ok and Cancel
                                primaryColor:
                                    kPrimaryColor, // Select date color
                                accentColor: kPrimaryColor, // Select date color
                              ),
                              child: child);
                        },
                      ).then((date) {
                        setState(() {
                          _date = date;
                        });
                      });
                    }),
                border: InputBorder.none,
              ),
            ),
          ),
          Center(
            child: AddButton(
              text: 'Add',
            ),
          ),
          SizedBox(
            height: 20.0,
          )
        ],
      ),
    );
  }

  Widget _textLabel(String label) => Text(label,
      textAlign: TextAlign.start,
      style: TextStyle(fontSize: 18.0, color: kPrimaryLightColor));
}
