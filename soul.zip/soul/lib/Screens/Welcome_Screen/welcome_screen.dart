import 'package:flutter/material.dart';
import 'package:soul/Components/rounded_button.dart';
import 'package:soul/Screens/Profile_Screen/Profile_Screen.dart';
import 'package:soul/constants.dart';
import 'package:soul/Screens/Signup_Screen/signup_screen.dart';
import 'package:soul/Screens/Login_Screen/Login.dart';
import 'package:soul/Components/circular_image.dart';
import 'package:soul/Screens/Medicine/add_medicine.dart';
import 'package:soul/Screens/Family_History_Screen/family_history.dart';
import 'package:soul/Screens/Medical_History_Screen/medical_history.dart';
import 'package:soul/Screens/Health_History_Screen/health_history.dart';
import'package:soul/Screens/Appoitments/add_appoitment.dart';
import 'package:soul/Screens/Appoitments/myAppointments/myAppointment.dart';
import 'package:soul/Screens/MainPage_Screen/main_page.dart';

class Welcome extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return  Container(
    color: Colors.white,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          CirculerImage(imageName: 'welcom.png',width: 200.0,height: 200.0,),
          SizedBox(height:30.0 ,),
          RoundedButton(
            text: 'Login',
            color: kPrimaryColor,
            press: (){
              Navigator.push(
                context,
                PageRouteBuilder(
                  transitionDuration: Duration(seconds: 1),
                  transitionsBuilder: (BuildContext context,
                      Animation<double> animation,
                      Animation<double> secAnimation,
                      Widget child) {
                    animation = CurvedAnimation(
                        parent: animation, curve: Curves.easeIn);
                    return ScaleTransition(
                      scale: animation,
                      child: child,
                      alignment: Alignment.center,
                    );
                  },
                  pageBuilder: (BuildContext context,
                      Animation<double> animation,
                      Animation<double> secAnimation) {
                    return Login();
                  },
                ),
              );
            },
          ),
          RoundedButton(
            text: 'Sign up',
            color: kPrimarySecColor,
            press: (){
              Navigator.push(
                context,
                PageRouteBuilder(
                  transitionDuration: Duration(seconds: 1),
                  transitionsBuilder: (BuildContext context,
                      Animation<double> animation,
                      Animation<double> secAnimation,
                      Widget child) {
                    animation = CurvedAnimation(
                        parent: animation, curve: Curves.easeIn);
                    return ScaleTransition(
                      scale: animation,
                      child: child,
                      alignment: Alignment.center,
                    );
                  },
                  pageBuilder: (BuildContext context,
                      Animation<double> animation,
                      Animation<double> secAnimation) {
                    return SignUp();
                  },
                ),
              );

            },
          )
        ],
      ),);


  }
}
