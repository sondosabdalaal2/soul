import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';


class BookAppointmentTab3 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ListView(
      children: [
        _listItem(),
        _listItem(),
        _listItem(),
        _listItem(),
      ],
    );
  }

  Widget _listItem() {
    return Container(
      margin: EdgeInsets.only(bottom: 20),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Container(
            width: 50.0,
            height: 50.0,
            decoration: new BoxDecoration(
              image: DecorationImage(
                image: AssetImage('assets/images/profile.png'),
                fit: BoxFit.cover,
              ),
              borderRadius: new BorderRadius.all(new Radius.circular(50.0)),
              border: new Border.all(
                color: Colors.white,
                width: 3.0,
              ),
            ),
          ),
          Expanded(
            child: Container(
              margin: EdgeInsets.only(left: 10),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    margin: EdgeInsets.only(left: 2, bottom: 3),
                    child: Text(
                      "User Name 1",
                      style: TextStyle(
                          color: Colors.black, fontWeight: FontWeight.w500),
                    ),
                  ),
                  RatingBarIndicator(
                    rating: 3,
                    itemBuilder: (context, index) => Icon(
                      Icons.star,
                      color: Colors.orange,
                    ),
                    itemCount: 5,
                    itemSize: 15.0,
                    itemPadding: EdgeInsets.all(0),
                    unratedColor: Colors.black.withOpacity(0.2),
                    direction: Axis.horizontal,
                  ),
                  Container(
                    margin: EdgeInsets.only(left: 2, bottom: 3, top: 5),
                    child: Text(
                      "You are never too busy to take my calls when I am stressed and feeling that at times I need support.",
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(color: Colors.black, fontSize: 14),
                    ),
                  )
                ],
              ),
            ),
          )
        ],
      ),
    );
  }
}
