import 'package:flutter/material.dart';
import 'package:soul/Components/background.dart';
import 'physicien.dart';
import 'data/sampleData.dart';

List<Map<String, dynamic>> _lstData = appointmentSlots();
class AddAppointment extends StatefulWidget {
  @override
  _AddAppointmentState createState() => _AddAppointmentState();
}

class _AddAppointmentState extends State<AddAppointment> {
  @override
  Widget build(BuildContext context) {
    Size size=MediaQuery.of(context).size;
    return Background(
      title: 'Add Appointment',
      child:  BookAppointment(),
    );
  }


}
