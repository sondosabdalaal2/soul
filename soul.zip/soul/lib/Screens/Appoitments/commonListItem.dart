import 'package:flutter/material.dart';
import 'package:soul/constants.dart';

class CommonListItem extends StatelessWidget {
  final Function onItemClicked;

  final String firstTitle;

  final String secondTitle;
  final IconData secondTitleIcon;

  final String thirdTitle;
  final IconData thirdTitleIcon;
  final Function onThirdClicked;

  final String fourthTitle;
  final IconData fourthTitleIconFront;
  final IconData fourthTitleIconRear;
  final Function onFourthClicked;

  const CommonListItem({
    Key key,
    this.firstTitle,
    this.secondTitle,
    this.thirdTitle,
    this.fourthTitle,
    this.onItemClicked,
    this.thirdTitleIcon,
    this.secondTitleIcon,
    this.fourthTitleIconFront,
    this.fourthTitleIconRear,
    this.onThirdClicked,
    this.onFourthClicked,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return InkWell(
        onTap: onItemClicked,
        child: Container(
          margin: EdgeInsets.symmetric(horizontal: 5),
          padding: EdgeInsets.only(bottom: 10, top: 15),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(firstTitle,
                      textAlign: TextAlign.start,
                      style: TextStyle(
                        fontSize: 14.0,
                        fontWeight: FontWeight.w300,
                        color: kPrimaryColor.withOpacity(0.8),
                      )),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      secondTitleIcon != null
                          ? Icon(
                              secondTitleIcon,
                              size: 14,
                              color:kPrimaryColor.withOpacity(0.6),
                            )
                          : Container(),
                      SizedBox(
                        width: secondTitle != null ? 5 : 0,
                      ),
                      secondTitle != null
                          ? Text(secondTitle,
                              textAlign: TextAlign.start,
                              style: TextStyle(
                                fontSize: 14.0,
                                fontWeight: FontWeight.w300,
                                color:
                                    kPrimaryColor.withOpacity(0.8),
                              ))
                          : Container()
                    ],
                  )
                ],
              ),
              SizedBox(
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Flexible(
                        child: InkWell(
                            onTap: onThirdClicked,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Flexible(
                                    child: Text(thirdTitle,
                                        overflow: TextOverflow.clip,
                                        softWrap: false,
                                        style: TextStyle(
                                          fontSize: 16.0,
                                          fontWeight: FontWeight.w600,
                                          color: kPrimaryColor,
                                        ))),
                                SizedBox(
                                  width: thirdTitleIcon != null ? 5 : 0,
                                ),
                                thirdTitleIcon != null
                                    ? Icon(
                                        thirdTitleIcon,
                                        size: 20,
                                      )
                                    : Container()
                              ],
                            ))),
                    InkWell(
                        onTap: onFourthClicked,
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            SizedBox(
                              width: fourthTitleIconFront != null ? 5 : 0,
                            ),
                            fourthTitleIconFront != null
                                ? Icon(
                                    fourthTitleIconFront,
                                    size: 16,
                                    color: kPrimaryColor,
                                  )
                                : Container(),
                            SizedBox(
                              width: fourthTitleIconFront != null ? 5 : 0,
                            ),
                            Text(fourthTitle,
                                style: TextStyle(
                                  fontSize: 15.0,
                                  fontWeight: FontWeight.w600,
                                  color: kPrimaryColor,
                                )),
                            SizedBox(
                              width: fourthTitleIconRear != null ? 5 : 0,
                            ),
                            fourthTitleIconRear != null
                                ? Icon(
                                    fourthTitleIconRear,
                                    size: 20,
                                    color: kPrimaryColor,
                                  )
                                : Container(),
                          ],
                        ))
                  ],
                ),
                height: 30,
              )
            ],
          ),
          decoration: const BoxDecoration(
            border: Border(
              bottom: BorderSide(width: 0.3, color: kPrimaryColor),
            ),
          ),
        ));
  }
}
