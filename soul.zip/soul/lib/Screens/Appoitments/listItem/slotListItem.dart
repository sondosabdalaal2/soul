import 'package:flutter/material.dart';


class SlotListItem extends StatelessWidget {
  final String date;
  final int slotAvailable;
  final List<String> timing;

  SlotListItem(this.date,this.slotAvailable,this.timing);

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 3,
      shadowColor: Colors.grey,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10.0),
      ),
      color: Colors.white,
      child: Container(
        padding: EdgeInsets.all(15),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Text(
                  date,
                  style: TextStyle(
                      color: Colors.black,
                      fontSize: 16,
                      fontWeight: FontWeight.w500),
                ),
                Container(
                  margin: EdgeInsets.only(top: 8),
                  child: Text(
                    "$slotAvailable Slots Available",
                    style: TextStyle(
                        color: Colors.black.withOpacity(0.4),
                        fontWeight: FontWeight.w300,
                        fontSize: 14),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                )
              ],
            ),
            SizedBox(
              height: 15,
            ),
            SizedBox(
              height: 30,
              width: 180,
              child: ListView.builder(
                shrinkWrap: true,
                scrollDirection: Axis.horizontal,
                itemCount: timing.length,
                itemBuilder: (BuildContext context, int index) {
                  var data = timing[index];
                  return Container(
                    margin: EdgeInsets.only(right: 10),
                    padding:
                        EdgeInsets.only(top: 5, bottom: 4, left: 12, right: 12),
                    decoration: BoxDecoration(
                      borderRadius:
                          new BorderRadius.all(new Radius.circular(10.0)),
                      border: new Border.all(
                        color: Colors.black.withOpacity(0.05),
                        width: 1.5,
                      ),
                    ),
                    child: Text(
                      data,
                      style: TextStyle(color: Colors.black, fontSize: 13),
                    ),
                  );
                },
              ),
            )
          ],
        ),
      ),
    );
  }
}
