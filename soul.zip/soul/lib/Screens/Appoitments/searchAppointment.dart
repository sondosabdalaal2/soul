import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'listItem/doctorListItem.dart';
import 'package:soul/constants.dart';
import 'package:intl/intl.dart';
import 'physicien.dart';
class SearchAppointment extends StatefulWidget {
  @override
  _SearchAppointmentState createState() => _SearchAppointmentState();
}

class _SearchAppointmentState extends State<SearchAppointment> {
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();
  DateTime _selectedDate = DateTime.now();
  TextEditingController _searchDocController = TextEditingController();
  TextEditingController _searchAreaController = TextEditingController();
  TextEditingController _dateController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Color(0xFFECF1FA),
        key: _scaffoldKey,
       // appBar: appBar(_scaffoldKey, context),
        body: SafeArea(
          child: Column(
            children: [
              toolbarView('Book a new appointment'),
              Expanded(
                child: SingleChildScrollView(
                  child: Container(
                    padding: EdgeInsets.only(left: 12, right: 12, top: 20),
                    child: Wrap(
                      crossAxisAlignment: WrapCrossAlignment.center,
                      runSpacing: 10,
                      children: [
                        _searchOne(),
                        _searchTow(),
                        _searchThree(),
                        _searchBtn(),
                        _listTitle(),
                        _listView()
                      ],
                    ),
                  ),
                ),
              )
            ],
          ),
        ),
        //drawer: CustomDrawer()
    );
  }

  Widget _searchOne() => textField(
      'Doctor, Specialities …', Icons.search, _searchDocController);

  Widget _searchTow() => textField('Select area',
      Icons.location_on_outlined, _searchAreaController);
  Widget textField(String hint, IconData iconData,
      TextEditingController textEditingController,
      {bool isReadonly = false, Function onTap, int minLines = 1}) =>
      Card(
        elevation: 3,
        shadowColor: kPrimaryColor,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10.0),
        ),
        child: TextField(
            autofocus: false,
            onTap: () {
              if (onTap != null) onTap.call();
            },
            minLines: minLines,
            maxLines: null,
            controller: textEditingController,
            showCursor: !isReadonly,
            readOnly: isReadonly,
            style: TextStyle(color: kPrimaryColor, fontSize: 18),
            decoration: new InputDecoration(
                border: InputBorder.none,
                focusedBorder: InputBorder.none,
                enabledBorder: InputBorder.none,
                errorBorder: InputBorder.none,
                disabledBorder: InputBorder.none,
                prefixIcon: iconData != null
                    ? IconButton(
                  icon: Icon(
                    iconData,
                    color:kPrimaryColor,
                  ),
                  onPressed: () {},
                )
                    : null,
                contentPadding:
                EdgeInsets.only(left: 10, bottom: 12, top: 12, right: 10),
                hintStyle: TextStyle(
                    fontSize: 18.0,
                    fontWeight: FontWeight.w300,
                    color: Colors.black.withOpacity(0.5)),
                hintText: hint)),
      );
  Widget _searchThree() => textField(
          'Select date', Icons.date_range, _dateController,
          isReadonly: true, onTap: () {
        final ThemeData theme = Theme.of(context);
        if (theme.platform == TargetPlatform.android)
          _openDatePicker();
        else
          _openDatePickerIOS();
      });

  Widget _searchBtn() => Container(
        margin: EdgeInsets.only(top: 10),
        width: MediaQuery.of(context).size.width,
        child: elevatedButton(
            text: 'Search',
            fontWeight: FontWeight.w500,
            color: kPrimaryColor,
            onPress: () {
              Navigator.push(context, PageRouteBuilder(
                transitionDuration: Duration(seconds: 1),
                transitionsBuilder: (BuildContext context,
                    Animation<double> animation,
                    Animation<double> secAnimation,
                    Widget child) {
                  animation = CurvedAnimation(
                      parent: animation, curve: Curves.easeIn);
                  return ScaleTransition(
                    scale: animation,
                    child: child,
                    alignment: Alignment.center,
                  );
                },
                pageBuilder: (BuildContext context,
                    Animation<double> animation,
                    Animation<double> secAnimation) {
                  return BookAppointment();
                },
              ),);
            }),
      );

  void _openDatePicker() async {
    final DateTime result = await showDatePicker(
      context: context,
      initialDate: _selectedDate,
      firstDate: DateTime(2000),
      lastDate: DateTime(2025),
    );
    if (result != null && result != _selectedDate)
      setState(() {
        _selectedDate = result;
        _dateController.text = dateFormat(_selectedDate);
      });
  }
  String dateFormat(DateTime dateTime) {
    final DateFormat formatter = DateFormat('dd MMM yyyy');
    final String formatted = formatter.format(dateTime);
    return formatted;
  }
  ElevatedButton elevatedButton(
      {@required String text,
        @required Color color,
        @required Function onPress,
        Color textColor = Colors.white,
        double textSize = 18,
        FontWeight fontWeight = FontWeight.w500,
        bool compactSize = false}) =>
      ElevatedButton(
          onPressed: () => {onPress.call()},
          child: Text(
            text,
            style: TextStyle(
                fontSize: textSize, color: textColor, fontWeight: fontWeight),
          ),
          style: ButtonStyle(
              backgroundColor: MaterialStateProperty.all<Color>(color),
              padding: MaterialStateProperty.all<EdgeInsetsGeometry>(
                  EdgeInsets.symmetric(vertical: compactSize ? 0 : 14)),
              shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                  RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8.0)))));

  void _openDatePickerIOS() async {
    showModalBottomSheet(
        context: context,
        builder: (BuildContext builder) {
          return Container(
            height: MediaQuery.of(context).copyWith().size.height / 3,
            color: Colors.white,
            child: CupertinoDatePicker(
              mode: CupertinoDatePickerMode.date,
              onDateTimeChanged: (result) {
                if (result != null && result != _selectedDate)
                  setState(() {
                    _selectedDate = result;
                    _dateController.text = dateFormat(_selectedDate);
                  });
              },
              initialDateTime: _selectedDate,
              minimumYear: 2000,
              maximumYear: 2025,
            ),
          );
        });

    final DateTime result = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2000),
      lastDate: DateTime(2025),
    );
    if (result != null && result != _selectedDate)
      setState(() {
        _selectedDate = result;
        _dateController.text = dateFormat(_selectedDate);
      });
  }
  Widget toolbarView(String label) => Container(
      height: 60.0,
      padding: EdgeInsets.only(left: 15, bottom: 10),
      alignment: Alignment.centerLeft,
      child: Text(label,
          style: TextStyle(
              color: kPrimaryColor,
              fontSize: 22,
              fontWeight: FontWeight.w600)),
      decoration: BoxDecoration(
          color: Colors.white,
          shape: BoxShape.rectangle,
          boxShadow: [
            BoxShadow(
              color: Colors.blueGrey.withOpacity(0.2),
              offset: const Offset(0, 1.0),
              blurRadius: 4.0,
              spreadRadius: 2.0,
            ),
          ]));

  Widget _listTitle() {
    return Container(
      margin: EdgeInsets.only(top: 20),
      child: Row(
        children: [
          Expanded(
              child: Text(
           'All Specielist',
            style: TextStyle(color: Colors.black, fontSize: 17),
          )),
          IconButton(
              iconSize: 30,
              alignment: Alignment.centerRight,
              icon: Icon(
                Icons.filter_list_sharp,
                color: kPrimaryColor,
              ),
              onPressed: () {})
        ],
      ),
    );
  }

  Widget _listView() {
    return ListView(
      shrinkWrap: true,
      physics: NeverScrollableScrollPhysics(),
      children: [
        DoctorListItem('assets/images/profile.png', "Dr.Marting Pilier",
            "Cardiologist", 3, 213),
        DoctorListItem('assets/images/profile.png', "Dr. Clara Odding",
            "Dentist", 4, 100),
        DoctorListItem('assets/images/profile.png', "Dr. Julien More",
            "Psychiatrist", 5, 180),
        DoctorListItem('assets/images/profile.png', "Dr. Jeff Smiths",
            "Dermatologist", 5, 223),
      ],
    );
  }
}
