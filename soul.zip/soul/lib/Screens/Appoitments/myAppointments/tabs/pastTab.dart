import 'package:flutter/material.dart';
import 'package:soul/Screens/Appoitments/commonListItem.dart';


class PastTab extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ListView(
      shrinkWrap: true,
      padding: EdgeInsets.zero,
      children: <Widget>[
        SizedBox(
          height: 10,
        ),
        CommonListItem(
          firstTitle: "09/04/2020",
          thirdTitle: "Dentist - Clara Odding",
          fourthTitle: "Feedback",
          thirdTitleIcon: Icons.info_outlined,
          fourthTitleIconFront: Icons.feedback_outlined,
          onThirdClicked: () {},
          onFourthClicked: () {
            //context.navigateToScreen(AddDoctorFeedback());
          },
        ),
        CommonListItem(
          firstTitle: "09/04/2020",
          thirdTitle: "Dentist - Clara Odding",
          fourthTitle: "Feedback",
          thirdTitleIcon: Icons.info_outlined,
          fourthTitleIconFront: Icons.feedback_outlined,
          onThirdClicked: () {},
          onFourthClicked: () {},
        ),
        CommonListItem(
          firstTitle: "09/04/2020",
          thirdTitle: "Dentist - Clara Odding",
          fourthTitle: "Feedback",
          thirdTitleIcon: Icons.info_outlined,
          fourthTitleIconFront: Icons.feedback_outlined,
          onThirdClicked: () {},
          onFourthClicked: () {},
        ),
        CommonListItem(
          firstTitle: "09/04/2020",
          thirdTitle: "Dentist - Clara Odding",
          fourthTitle: "Feedback",
          thirdTitleIcon: Icons.info_outlined,
          fourthTitleIconFront: Icons.feedback_outlined,
          onThirdClicked: () {},
          onFourthClicked: () {},
        ),
        CommonListItem(
          firstTitle: "09/04/2020",
          thirdTitle: "Dentist - Clara Odding",
          fourthTitle: "Feedback",
          thirdTitleIcon: Icons.info_outlined,
          fourthTitleIconFront: Icons.feedback_outlined,
          onThirdClicked: () {},
          onFourthClicked: () {},
        ),
        CommonListItem(
          firstTitle: "09/04/2020",
          thirdTitle: "Dentist - Clara Odding",
          fourthTitle: "Feedback",
          thirdTitleIcon: Icons.info_outlined,
          fourthTitleIconFront: Icons.feedback_outlined,
          onThirdClicked: () {},
          onFourthClicked: () {},
        ),
      ],
    );
  }
}
