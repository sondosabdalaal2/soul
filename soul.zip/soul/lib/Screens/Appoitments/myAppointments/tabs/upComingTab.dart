import 'package:flutter/material.dart';
import 'package:soul/Screens/Appoitments/commonListItem.dart';

class UpComingTab extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ListView(
      shrinkWrap: true,
      padding: EdgeInsets.zero,
      children: <Widget>[
        SizedBox(
          height: 10,
        ),
        CommonListItem(
          firstTitle: "09/04/2020",
thirdTitle: "Dentist - Clara Odding",
          fourthTitle: "Modify",
          thirdTitleIcon: Icons.info_outlined,
          fourthTitleIconFront: Icons.edit_outlined,
          onThirdClicked: () {},
          onFourthClicked: () {},
        ),
        CommonListItem(
          firstTitle: "09/04/2020",
thirdTitle: "Dentist - Clara Odding",
          fourthTitle: "Modify",
          thirdTitleIcon: Icons.info_outlined,
          fourthTitleIconFront: Icons.edit_outlined,
          onThirdClicked: () {},
          onFourthClicked: () {},
        ),
        CommonListItem(
          firstTitle: "09/04/2020",
thirdTitle: "Dentist - Clara Odding",
          fourthTitle: "Modify",
          thirdTitleIcon: Icons.info_outlined,
          fourthTitleIconFront: Icons.edit_outlined,
          onThirdClicked: () {},
          onFourthClicked: () {},
        ),
        CommonListItem(
          firstTitle: "09/04/2020",
thirdTitle: "Dentist - Clara Odding",
          fourthTitle: "Modify",
          thirdTitleIcon: Icons.info_outlined,
          fourthTitleIconFront: Icons.edit_outlined,
          onThirdClicked: () {},
          onFourthClicked: () {},
        ),
        CommonListItem(
          firstTitle: "09/04/2020",
thirdTitle: "Dentist - Clara Odding",
          fourthTitle: "Modify",
          thirdTitleIcon: Icons.info_outlined,
          fourthTitleIconFront: Icons.edit_outlined,
          onThirdClicked: () {},
          onFourthClicked: () {},
        ),
      ],
    );
  }
}
