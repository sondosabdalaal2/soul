import 'package:flutter/material.dart';
import 'package:soul/Screens/Appoitments/add_appoitment.dart';
import 'package:soul/Screens/Appoitments/physicien.dart';
import 'tabs/pastTab.dart';
import 'tabs/upComingTab.dart';
import 'package:soul/constants.dart';
import 'package:soul/Screens/Appoitments/searchAppointment.dart';



class MyAppointments extends StatefulWidget {
  @override
  _MyAppointmentsState createState() => _MyAppointmentsState();
}

class _MyAppointmentsState extends State<MyAppointments> {
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
        length: 2,
        child: Scaffold(
            backgroundColor: Color(0xFFECF1FA),
            body: SafeArea(
              child: Container(
                margin: EdgeInsets.fromLTRB(12, 0, 12, 0),
                child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      _titleHeader(),
                      searchTextField(),
                      _tabBarContainer(),
                      _tabsHolder(),
                      _bookAppointmentButton()
                    ]),
              ),
            )));
  }

  Widget _titleHeader() => Container(
      height: 50.0,
      padding: EdgeInsets.only(bottom: 10, top: 10),
      alignment: Alignment.topLeft,
      child: Text('My Apoointment',
          style: TextStyle(
              color: kPrimaryColor,
              fontSize: 18,
              fontWeight: FontWeight.w600),),);

  Widget _tabBarContainer() => Container(
      decoration: const BoxDecoration(
        border: Border(
          bottom: BorderSide(width: 0.3, color: kPrimaryLightColor),
        ),
      ),
      child: TabBar(
          isScrollable: true,
          indicatorSize: TabBarIndicatorSize.label,
          indicator: UnderlineTabIndicator(
              borderSide: BorderSide(width: 2.0, color: kPrimaryColor)),
          unselectedLabelColor: kPrimaryColor,
          labelColor: kPrimarySecColor,
          labelPadding: EdgeInsets.symmetric(horizontal: 10),
          tabs: [
            Tab(
              child: Align(
                child: Text('Up Coming',
                    textAlign: TextAlign.start,
                    style:
                        TextStyle(fontSize: 16.0, fontWeight: FontWeight.w600)),
                alignment: Alignment.centerLeft,
              ),
            ),
            Tab(
              child: Align(
                child: Text('Past',
                    textAlign: TextAlign.end,
                    style:
                        TextStyle(fontSize: 16.0, fontWeight: FontWeight.w600)),
                alignment: Alignment.centerRight,
              ),
            ),
          ]));

  Widget _tabsHolder() => Expanded(
        child: TabBarView(children: [
          UpComingTab(),
          PastTab(),
        ]),
      );

  Widget _bookAppointmentButton() {
    return Container(
        width: MediaQuery.of(context).size.width,
        child: elevatedButton(
            text: 'Book',
            color: kPrimaryColor,
            fontWeight: FontWeight.w500,
            onPress: () {
              Navigator.push(context, PageRouteBuilder(
                transitionDuration: Duration(seconds: 1),
                transitionsBuilder: (BuildContext context,
                    Animation<double> animation,
                    Animation<double> secAnimation,
                    Widget child) {
                  animation = CurvedAnimation(
                      parent: animation, curve: Curves.easeIn);
                  return ScaleTransition(
                    scale: animation,
                    child: child,
                    alignment: Alignment.center,
                  );
                },
                pageBuilder: (BuildContext context,
                    Animation<double> animation,
                    Animation<double> secAnimation) {
                  return SearchAppointment();
                },
              ),);
            }),
        margin: EdgeInsets.only(top: 20, bottom: 10));
  }
  Widget searchTextField() {
    return Card(
      elevation: 5,
      shadowColor: Colors.grey,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10.0),
      ),
      child: Padding(
        padding: const EdgeInsets.only(left: 15),
        child: _textField(),
      ),
    );
  }
  TextField _textField() => TextField(
      autofocus: false,
      style: TextStyle(color: Colors.black, fontSize: 18),
      decoration: new InputDecoration(
          border: InputBorder.none,
          focusedBorder: InputBorder.none,
          enabledBorder: InputBorder.none,
          errorBorder: InputBorder.none,
          disabledBorder: InputBorder.none,
          suffixIcon: Icon(
            Icons.search_outlined,
            color: Colors.black.withOpacity(0.3),
          ),
          contentPadding:
          EdgeInsets.only(left: 5, bottom: 16, top: 16, right: 15),
          hintStyle: TextStyle(
              fontSize: 18.0,
              fontWeight: FontWeight.w400,
              color: Colors.black.withOpacity(0.3)),
          hintText:'Search'));
  ElevatedButton elevatedButton(
      {@required String text,
        @required Color color,
        @required Function onPress,
        Color textColor = Colors.white,
        double textSize = 18,
        FontWeight fontWeight = FontWeight.w500,
        bool compactSize = false}) =>
      ElevatedButton(
          onPressed: () => {onPress.call()},
          child: Text(
            text,
            style: TextStyle(
                fontSize: textSize, color: textColor, fontWeight: fontWeight),
          ),
          style: ButtonStyle(
              backgroundColor: MaterialStateProperty.all<Color>(color),
              padding: MaterialStateProperty.all<EdgeInsetsGeometry>(
                  EdgeInsets.symmetric(vertical: compactSize ? 0 : 14)),
              shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                  RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8.0)))));
}
