List<Map<String, dynamic>> appointmentSlots() => [
      {
        "date": "Thu, 09 Apr",
        "availableSlot": 3,
        "timing": ["08:00", "12:00", "15:00", "08:00", "12:00", "15:00"]
      },
      {
        "date": "Fri, 10 Apr",
        "availableSlot": 3,
        "timing": ["08:00", "12:00", "15:00"]
      },
      {
        "date": "Sat, 11 Apr",
        "availableSlot": 3,
        "timing": ["08:00", "12:00", "15:00"]
      }
    ];
