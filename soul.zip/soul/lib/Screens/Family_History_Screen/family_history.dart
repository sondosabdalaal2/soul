import 'package:flutter/material.dart';
import 'package:soul/constants.dart';
import 'package:soul/Components/rounded_input_field.dart';
import 'package:soul/Components/addButton.dart';
import 'package:soul/Components/background.dart';
class FamilyHistory extends StatefulWidget {
  @override
  _FamilyHistoryState createState() => _FamilyHistoryState();
}

class _FamilyHistoryState extends State<FamilyHistory> {
  @override
  Widget build(BuildContext context) {
    return Background(
      title: 'Add Family History',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            height: 20.0,
          ),
          _textLabel('Relation'),
          RoundedInputField(
            icon: null,
          ),
          _textLabel('Disease'),
          RoundedInputField(
            icon: null,
          ),
          _textLabel('Person Name'),
          RoundedInputField(
            icon: null,
          ),
          Center(
            child: AddButton(
              text: 'Add',
            ),
          ), SizedBox(height: 20.0,)
        ],
      ),
    );
  }

  Widget _textLabel(String label) => Text(label,
      textAlign: TextAlign.start,
      style: TextStyle(fontSize: 18.0, color: kPrimaryLightColor));


}
