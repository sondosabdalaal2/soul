import 'package:flutter/material.dart';
import 'package:soul/Screens/Profile_Screen/Profile_Screen.dart';
import 'package:soul/constants.dart';
import 'package:soul/Screens/Home_Screen/home.dart';
import 'package:soul/Components/placeholder_widget.dart';
import 'package:flutter_svg/svg.dart';
import 'package:soul/Components/circular_image.dart';
import 'package:soul/Screens/Health_History_Screen/health_history.dart';
import 'package:soul/Screens/Lab_Screen/lab.dart';

class MainPage extends StatefulWidget {
  @override
  _MainPageState createState() => _MainPageState();
}

class _MainPageState extends State<MainPage> {
  bool flag = true;

  int _currentIndex = 0;

  void onTabTapped(int index) {
    setState(() {
      _currentIndex = index;
    });
  }

  final List<Widget> _children = [
    PlaceholderWidget(HomePage()),
    PlaceholderWidget(Container()),
    PlaceholderWidget(HealthHistory()),
    PlaceholderWidget(LabResult()),

  ];

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(

        body: _children[_currentIndex],
        floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
        floatingActionButton: InkWell(
          onTap: (){
            Navigator.push(
                context,
                PageRouteBuilder(
                transitionDuration: Duration(seconds: 1),
            transitionsBuilder: (BuildContext context,
            Animation<double> animation,
            Animation<double> secAnimation,
            Widget child) {
            animation = CurvedAnimation(
            parent: animation, curve: Curves.easeIn);
            return ScaleTransition(
            scale: animation,
            child: child,
            alignment: Alignment.center,
            );
            },
            pageBuilder: (BuildContext context,
            Animation<double> animation,
            Animation<double> secAnimation) {
            return Profile();
            },
            ),
            );
          },
          child: CirculerImage(
            imageName: 'profile.png',
            width: 50.0,
            height: 50.0,
          ),
        ),
        bottomNavigationBar: BottomAppBar(
          color: kPrimaryColor,
          shape: CircularNotchedRectangle(),
          child: BottomNavigationBar(
            type: BottomNavigationBarType.fixed,
            backgroundColor: kPrimaryLightColor,
            onTap: onTabTapped,
            currentIndex: _currentIndex, // new
            items: [
              BottomNavigationBarItem(
                  icon: SvgPicture.asset(
                    'assets/icons/home.svg',
                    height: 20.0,
                    width: 20.0,
                  ),
                  activeIcon: SvgPicture.asset(
                    'assets/icons/home.svg',
                    height: 20.0,
                    width: 20.0,
                    color: Colors.white,
                  ),
                  label: 'Home',
                  backgroundColor: kPrimaryLightColor),
              BottomNavigationBarItem(
                  icon: SvgPicture.asset(
                    'assets/icons/calendar.svg',
                    height: 20.0,
                    width: 20.0,
                  ),
                  activeIcon: SvgPicture.asset(
                    'assets/icons/calendar.svg',
                    height: 20.0,
                    width: 20.0,
                    color: Colors.white,
                  ),
                  label: 'Calendar',
                  backgroundColor: kPrimaryLightColor),
              BottomNavigationBarItem(
                  icon: SvgPicture.asset(
                    'assets/icons/health-history.svg',
                    height: 20.0,
                    width: 20.0,
                  ),
                  activeIcon: SvgPicture.asset(
                    'assets/icons/health-history.svg',
                    height: 20.0,
                    width: 20.0,
                    color: Colors.white,
                  ),
                  label: 'Health History',
                  backgroundColor: kPrimaryLightColor),

              BottomNavigationBarItem(
                  icon: SvgPicture.asset(
                    'assets/icons/lab.svg',
                    height: 20.0,
                    width: 20.0,
                  ),
                  activeIcon: SvgPicture.asset(
                    'assets/icons/lab.svg',
                    height: 20.0,
                    width: 20.0,
                    color: Colors.white,
                  ),
                  label: 'Lab Result',
                  backgroundColor: kPrimaryLightColor),
            ],
          ),
        ),
      ),
    );
  }
}


