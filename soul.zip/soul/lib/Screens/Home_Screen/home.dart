import 'package:flutter/material.dart';
import 'package:soul/constants.dart';
import 'package:soul/Components/roundedRec.dart';
import 'package:soul/Screens/Medicine/add_medicine.dart';
import 'package:soul/Screens/Appoitments/myAppointments/myAppointment.dart';
import 'package:soul/Screens/Allergy/allergy.dart';
import 'package:soul/Screens/Family_History_Screen/family_history.dart';
import 'package:soul/Screens/Medical_History_Screen/medical_history.dart';
import 'package:soul/Screens/Vital_Screen/Vital_Signs.dart';

class HomePage extends StatelessWidget {
  // const HomePage({
  //   Key key,
  //    //this.flag,
  // }) : super(key: key);

  //final bool flag;
  bool flag=true;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: kPrimaryLightColor,
        appBar: PreferredSize(
          preferredSize: Size.fromHeight(100.0),
          child: AppBar(
            elevation: 6.0,
            backgroundColor: kPrimaryColor,
            shape: ContinuousRectangleBorder(
              borderRadius: const BorderRadius.only(
                  bottomLeft: Radius.circular(30.0),
                  bottomRight: Radius.circular(30.0)),
            ),
            title: Align(
              alignment: Alignment.center,
              child: Column(children: [
                SizedBox(
                  height: 30,
                ),
                Text('HOME',
                    style: TextStyle(
                        fontSize: 40,
                        fontWeight: FontWeight.bold,
                        color: Colors.white)),
              ]),
            ),
          ),
        ),
        body: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                color: kPrimaryLightColor,
                padding: EdgeInsets.only(
                    top: 20.0, left: 30.0, right: 30.0, bottom: 30.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      'Today',
                      style: TextStyle(fontSize: 30, color: Colors.white),
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    flag
                        ? Column(children: [
                      Row(children: [
                        SizedBox(
                          width: 5,
                        ),
                        Expanded(
                          child: Container(
                            child: Expanded(
                              child: Column(
                                  crossAxisAlignment:
                                  CrossAxisAlignment.start,
                                  children: <Widget>[
                                    SizedBox(
                                      height: 8,
                                    ),
                                    Row(children: [
                                      SizedBox(
                                        width: 20,
                                      ),
                                      Text(
                                        'Appitment Confirmation',
                                        style: TextStyle(
                                            fontSize: 15,
                                            fontWeight: FontWeight.bold,
                                            color: kPrimaryLightColor),
                                      ),
                                    ]),
                                    SizedBox(
                                      height: 10,
                                    ),
                                    Row(
                                      children: [
                                        SizedBox(
                                          width: 10,
                                        ),
                                        Expanded(
                                            child: Text(
                                                'You have an appoitment today with:Dr.Husam at 3:00 pm')),
                                      ],
                                    ),
                                    SizedBox(
                                      height: 5,
                                    ),
                                    Row(children: [
                                      SizedBox(
                                        width: 5,
                                      ),
                                      Expanded(
                                          child: IconButton(
                                              icon: Icon(
                                                Icons.check_box,
                                                color:
                                                kPrimaryLightColor,
                                              ),
                                              onPressed: () {})),
                                      SizedBox(
                                        width: 2,
                                      ),
                                      Expanded(
                                          child: IconButton(
                                              icon: Icon(Icons.cancel,
                                                  color: Colors.red),
                                              onPressed: () {})),
                                    ])
                                  ]),
                            ),
                            width: 100,
                            height: 125,
                            decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(40),
                                border: Border.all(color: Colors.white)),
                          ),
                        ),
                      ]),
                      SizedBox(
                        height: 10,
                      ),
                      Row(children: [
                        SizedBox(
                          width: 5,
                        ),
                        Expanded(
                          child: Container(
                            child: Expanded(
                              child: Column(
                                  crossAxisAlignment:
                                  CrossAxisAlignment.start,
                                  children: <Widget>[
                                    SizedBox(
                                      height: 8,
                                    ),
                                    Row(children: [
                                      SizedBox(
                                        width: 20,
                                      ),
                                      Text(
                                        'Medicine Reminder',
                                        style: TextStyle(
                                            fontSize: 15,
                                            fontWeight: FontWeight.bold,
                                            color: kPrimaryLightColor),
                                      ),
                                    ]),
                                    SizedBox(
                                      height: 10,
                                    ),
                                    Row(
                                      children: [
                                        SizedBox(
                                          width: 10,
                                        ),
                                        Expanded(
                                            child: Text(
                                                'Do not forget to take your drugs: acamol and concor.')),
                                      ],
                                    ),
                                    SizedBox(
                                      height: 5,
                                    ),
                                    Row(children: [
                                      SizedBox(
                                        width: 5,
                                      ),
                                      Expanded(
                                          child: IconButton(
                                              icon: Icon(
                                                Icons.check_box,
                                                color:
                                                kPrimaryLightColor,
                                              ),
                                              onPressed: () {})),
                                      SizedBox(
                                        width: 2,
                                      ),
                                      Expanded(
                                          child: IconButton(
                                              icon: Icon(Icons.cancel,
                                                  color: Colors.red),
                                              onPressed: () {})),
                                    ])
                                  ]),
                            ),
                            width: 100,
                            height: 125,
                            decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(40),
                                border: Border.all(color: Colors.white)),
                          ),
                        ),
                      ])
                    ])
                        : Text('You Don not have any reminders Yet',
                        style:
                        TextStyle(fontSize: 18.5, color: Colors.white)),
                    SizedBox(
                      height: 2,
                    ),
                  ],
                ),
              ),
              Container(
                padding: EdgeInsets.symmetric(horizontal: 20.0),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(50.0),
                    topRight: Radius.circular(50.0),
                  ),
                ),
                child: Column(
                  children: [
                    SizedBox(height: 30),
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: <Widget>[
                        CircleAvatar(
                          radius: 15.0,
                          backgroundColor: kPrimaryColor,
                          child: Icon(
                            Icons.add,
                            size: 30.0,
                            color: Colors.white,
                          ),
                        ),
                        SizedBox(
                          width: 15.0,
                        ),
                        Text(
                          'Add ',
                          style: TextStyle(
                            color: kPrimaryColor,
                            fontSize: 30.0,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ],
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    Row(children: [
                      RoundedRectContainer(
                        text: 'Medecine',
                        onTap:
                        (){
                          Navigator.push(
                              context,
                              PageRouteBuilder(
                              transitionDuration: Duration(seconds: 1),
                          transitionsBuilder: (BuildContext context,
                          Animation<double> animation,
                          Animation<double> secAnimation,
                          Widget child) {
                          animation = CurvedAnimation(
                          parent: animation, curve: Curves.easeIn);
                          return ScaleTransition(
                          scale: animation,
                          child: child,
                          alignment: Alignment.center,
                          );
                          },
                          pageBuilder: (BuildContext context,
                          Animation<double> animation,
                          Animation<double> secAnimation) {
                          return Medecine();
                          },
                          ),);
                        },
                      ),
                      SizedBox(
                        width: 10,
                      ),
                      RoundedRectContainer(
                        text: 'Appointment',
                        onTap: ()
                        {
                          Navigator.push(
                            context,
                            PageRouteBuilder(
                              transitionDuration: Duration(seconds: 1),
                              transitionsBuilder: (BuildContext context,
                                  Animation<double> animation,
                                  Animation<double> secAnimation,
                                  Widget child) {
                                animation = CurvedAnimation(
                                    parent: animation, curve: Curves.easeIn);
                                return ScaleTransition(
                                  scale: animation,
                                  child: child,
                                  alignment: Alignment.center,
                                );
                              },
                              pageBuilder: (BuildContext context,
                                  Animation<double> animation,
                                  Animation<double> secAnimation) {
                                return MyAppointments();
                              },
                            ),);
                        },
                      ),
                    ]),
                    SizedBox(
                      height: 10,
                    ),
                    Row(children: [
                      RoundedRectContainer(
                        text: 'Allergy',
                        onTap: ()
                        {
                          Navigator.push(
                            context,
                            PageRouteBuilder(
                              transitionDuration: Duration(seconds: 1),
                              transitionsBuilder: (BuildContext context,
                                  Animation<double> animation,
                                  Animation<double> secAnimation,
                                  Widget child) {
                                animation = CurvedAnimation(
                                    parent: animation, curve: Curves.easeIn);
                                return ScaleTransition(
                                  scale: animation,
                                  child: child,
                                  alignment: Alignment.center,
                                );
                              },
                              pageBuilder: (BuildContext context,
                                  Animation<double> animation,
                                  Animation<double> secAnimation) {
                                return Allergy();
                              },
                            ),);
                        },
                      ),
                      SizedBox(
                        width: 10,
                      ),
                      RoundedRectContainer(
                        text: 'Family History',
                        onTap: ()
                        {
                          Navigator.push(
                            context,
                            PageRouteBuilder(
                              transitionDuration: Duration(seconds: 1),
                              transitionsBuilder: (BuildContext context,
                                  Animation<double> animation,
                                  Animation<double> secAnimation,
                                  Widget child) {
                                animation = CurvedAnimation(
                                    parent: animation, curve: Curves.easeIn);
                                return ScaleTransition(
                                  scale: animation,
                                  child: child,
                                  alignment: Alignment.center,
                                );
                              },
                              pageBuilder: (BuildContext context,
                                  Animation<double> animation,
                                  Animation<double> secAnimation) {
                                return FamilyHistory();
                              },
                            ),);
                        },
                      ),
                    ]),
                    SizedBox(
                      height: 10,
                    ),
                    Row(children: [
                      RoundedRectContainer(
                        text: 'Medical History',
                        onTap: ()
                        {
                          Navigator.push(
                            context,
                            PageRouteBuilder(
                              transitionDuration: Duration(seconds: 1),
                              transitionsBuilder: (BuildContext context,
                                  Animation<double> animation,
                                  Animation<double> secAnimation,
                                  Widget child) {
                                animation = CurvedAnimation(
                                    parent: animation, curve: Curves.easeIn);
                                return ScaleTransition(
                                  scale: animation,
                                  child: child,
                                  alignment: Alignment.center,
                                );
                              },
                              pageBuilder: (BuildContext context,
                                  Animation<double> animation,
                                  Animation<double> secAnimation) {
                                return MedicalHistory();
                              },
                            ),);
                        },
                      ),
                      SizedBox(
                        width: 10,
                      ),
                      RoundedRectContainer(
                        text: 'Vital Signs',
                        onTap: ()
                        {
                          Navigator.push(
                            context,
                            PageRouteBuilder(
                              transitionDuration: Duration(seconds: 1),
                              transitionsBuilder: (BuildContext context,
                                  Animation<double> animation,
                                  Animation<double> secAnimation,
                                  Widget child) {
                                animation = CurvedAnimation(
                                    parent: animation, curve: Curves.easeIn);
                                return ScaleTransition(
                                  scale: animation,
                                  child: child,
                                  alignment: Alignment.center,
                                );
                              },
                              pageBuilder: (BuildContext context,
                                  Animation<double> animation,
                                  Animation<double> secAnimation) {
                                return Vitals();
                              },
                            ),);
                        },
                      ),
                    ]),
                    SizedBox(
                      height: 10,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}