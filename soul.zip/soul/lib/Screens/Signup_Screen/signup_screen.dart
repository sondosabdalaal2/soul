import 'package:flutter/material.dart';
import 'package:soul/Components/rounded_button.dart';
import 'package:soul/Components/rounded_input_field.dart';
import 'package:soul/Components/text_field_container.dart';
import 'package:soul/constants.dart';
import 'package:soul/Components/or_driver.dart';
import 'package:soul/Components/social.dart';
import 'package:soul/Components/already_have_an_account_acheck.dart';
import 'package:soul/Screens/Login_Screen/Login.dart';
import 'package:soul/Screens/MainPage_Screen/main_page.dart';

class SignUp extends StatefulWidget {
  @override
  _SignUpState createState() => _SignUpState();
}

class _SignUpState extends State<SignUp> {
  DateTime _birthDate;
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Container(
          color: Colors.white,
          child: SingleChildScrollView(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                SizedBox(
                  height: 15.0,
                ),
                Text(
                  'SIGNUP',
                  style: TextStyle(
                      color: kPrimaryColor,
                      fontSize: 50,
                      fontWeight: FontWeight.bold),
                ),
                RoundedInputField(
                  hintText: 'First Name',
                  icon: null,
                ),
                RoundedInputField(
                  hintText: 'Last Name',
                  icon: null,
                ),
                TextFieldContainer(
                  child: Center(
                    child: TextField(
                      decoration: InputDecoration(
                        hintText: 'Birthday',
                        hintStyle: TextStyle(color: Colors.grey.shade400),
                        suffixIcon: IconButton(
                            icon: Icon(
                              Icons.date_range_rounded,
                              color: kPrimaryColor,
                            ),
                            onPressed: () {
                              showDatePicker(
                                context: context,
                                initialDate: DateTime.now(), // Current Date
                                firstDate: DateTime(1900), // First date
                                lastDate: DateTime(2200), // Last Date
                                builder: (BuildContext context, Widget child) {
                                  return Theme(
                                      data: ThemeData(
                                        primarySwatch:
                                            txtColor, // Color of Ok and Cancel
                                        primaryColor:
                                            kPrimaryColor, // Select date color
                                        accentColor:
                                            kPrimaryColor, // Select date color
                                      ),
                                      child: child);
                                },
                              ).then((date) {
                                setState(() {
                                  _birthDate = date;
                                });
                              });
                            }),
                        border: InputBorder.none,
                      ),
                    ),
                  ),
                ),
                RoundedInputField(
                  hintText: 'Phone Number',
                  icon: null,
                ),
                RoundedInputField(
                  hintText: 'Email',
                  icon: null,
                ),
                RoundedInputField(
                  hintText: 'Password',
                  icon: null,
                ),
                RoundedButton(
                  text: 'Signup',
                  press: (){
                    Navigator.push(
                      context,
                      PageRouteBuilder(
                        transitionDuration: Duration(seconds: 1),
                        transitionsBuilder: (BuildContext context,
                            Animation<double> animation,
                            Animation<double> secAnimation,
                            Widget child) {
                          animation = CurvedAnimation(
                              parent: animation, curve: Curves.easeIn);
                          return ScaleTransition(
                            scale: animation,
                            child: child,
                            alignment: Alignment.center,
                          );
                        },
                        pageBuilder: (BuildContext context,
                            Animation<double> animation,
                            Animation<double> secAnimation) {
                          return MainPage();
                        },
                      ),
                    );
                  },
                ),
                OrDivider(),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    SocalIcon(
                      iconSrc: "assets/icons/facebook.svg",
                      press: () {},
                    ),
                    SocalIcon(
                      iconSrc: "assets/icons/twitter.svg",
                      press: () {},
                    ),
                    SocalIcon(
                      iconSrc: "assets/icons/google-plus.svg",
                      press: () {},
                    ),

                  ],
                ),
                SizedBox(height: 20.0,),
                AlreadyHaveAnAccountCheck(
                  login: false,
                  press: () {
                    Navigator.push(
                      context,
                      PageRouteBuilder(
                        transitionDuration: Duration(seconds: 1),
                        transitionsBuilder: (BuildContext context,
                            Animation<double> animation,
                            Animation<double> secAnimation,
                            Widget child) {
                          animation = CurvedAnimation(
                              parent: animation, curve: Curves.easeIn);
                          return ScaleTransition(
                            scale: animation,
                            child: child,
                            alignment: Alignment.center,
                          );
                        },
                        pageBuilder: (BuildContext context,
                            Animation<double> animation,
                            Animation<double> secAnimation) {
                          return Login();
                        },
                      ),
                    );
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
