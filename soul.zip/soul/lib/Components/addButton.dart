import 'package:flutter/material.dart';
import 'package:soul/constants.dart';

class AddButton extends StatelessWidget {
  final String text;
  final Function press;
  const AddButton({
    Key key,
    this.text,
    this.press,

  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Container(
      margin: EdgeInsets.symmetric(vertical: 10),
      width: size.width * 0.3,
      height: size.height * 0.08,
      child: ClipRRect(

        child: TextButton(
          style: TextButton.styleFrom(
            padding: EdgeInsets.symmetric(vertical: 20, horizontal: 40),
            backgroundColor: kPrimaryLightColor,
          ),
          onPressed: press,
          child: Align(
            alignment: Alignment.center,
            child: Text(
              text,
              style: TextStyle(color: Colors.white),
            ),
          ),
        ),
      ),
    );
  }
}
