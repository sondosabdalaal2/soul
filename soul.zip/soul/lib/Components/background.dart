import 'package:flutter/material.dart';
import 'package:soul/constants.dart';
import 'package:soul/Components/circular_image.dart';
import 'package:flutter_svg/svg.dart';
import 'package:soul/Components/placeholder_widget.dart';
class Background extends StatefulWidget {
  final title;
  final child;

  Background({this.title,this.child});

  @override
  _BackgroundState createState() => _BackgroundState();
}

class _BackgroundState extends State<Background> {
  int _currentIndex = 0;

  void onTabTapped(int index) {
    setState(() {
      _currentIndex = index;
    });
  }
  final List<Widget> _children = [
    PlaceholderWidget(Container()),
    PlaceholderWidget(Container()),
    PlaceholderWidget(Container()),

  ];
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: kPrimaryColor,
        body: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: EdgeInsets.only(
                  top: 60.0, left: 30.0, right: 30.0, bottom: 30.0),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: <Widget>[
                  CircleAvatar(
                    radius: 15.0,
                    backgroundColor: Colors.white,
                    child: Icon(
                      Icons.add,
                      size: 30.0,
                      color: kPrimaryColor,
                    ),
                  ),
                  SizedBox(
                    width: 15.0,
                  ),
                  Expanded(
                    child: Text(
                      widget.title,
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 30.0,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: Container(
                padding: EdgeInsets.symmetric(horizontal: 20.0),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(50.0),
                    topRight: Radius.circular(50.0),
                  ),
                ),
                child: SingleChildScrollView(
                  child: widget.child,
                ),
              ),
            ),
          ],
        ),
        floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
        floatingActionButton: CirculerImage(
          imageName: 'profile.png',
          width: 50.0,
          height: 50.0,
        ),
        bottomNavigationBar: BottomAppBar(
          color: kPrimaryColor,
          shape: CircularNotchedRectangle(),
          child: BottomNavigationBar(
            type: BottomNavigationBarType.fixed,
            backgroundColor: kPrimaryLightColor,
             onTap: onTabTapped,
             currentIndex: _currentIndex, // new
            items: [
              BottomNavigationBarItem(
                  icon: SvgPicture.asset(
                    'assets/icons/home.svg',
                    height: 20.0,
                    width: 20.0,
                  ),
                  activeIcon: SvgPicture.asset(
                    'assets/icons/home.svg',
                    height: 20.0,
                    width: 20.0,
                    color: Colors.white,
                  ),
                  label: 'Home',
                  backgroundColor: kPrimaryLightColor),
              BottomNavigationBarItem(
                  icon: SvgPicture.asset(
                    'assets/icons/calendar.svg',
                    height: 20.0,
                    width: 20.0,
                  ),
                  activeIcon: SvgPicture.asset(
                    'assets/icons/calendar.svg',
                    height: 20.0,
                    width: 20.0,
                    color: Colors.white,
                  ),
                  label: 'Calendar',
                  backgroundColor: kPrimaryLightColor),
              BottomNavigationBarItem(
                  icon: SvgPicture.asset(
                    'assets/icons/health-history.svg',
                    height: 20.0,
                    width: 20.0,
                  ),
                  activeIcon: SvgPicture.asset(
                    'assets/icons/health-history.svg',
                    height: 20.0,
                    width: 20.0,
                    color: Colors.white,
                  ),
                  label: 'Health History',
                  backgroundColor: kPrimaryLightColor),

              BottomNavigationBarItem(
                  icon: SvgPicture.asset(
                    'assets/icons/lab.svg',
                    height: 20.0,
                    width: 20.0,
                  ),
                  activeIcon: SvgPicture.asset(
                    'assets/icons/lab.svg',
                    height: 20.0,
                    width: 20.0,
                    color: Colors.white,
                  ),
                  label: 'Lab Result',
                  backgroundColor: kPrimaryLightColor),
            ],
          ),
        ),
      ),
    );
  }
}


