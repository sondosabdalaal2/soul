import 'package:flutter/material.dart';

const kPrimaryColor = Color(0xFF0678D9);
const kPrimaryLightColor = Color(0xFF55A2F2);
const kPrimarySecColor = Color(0xFF59C3F1);
const kPrimaryThirdColor = Color(0xFF39CAD7);
const kFontSize = 20.0;
const MaterialColor txtColor = MaterialColor(0xFF0678D9, <int, Color>{
  50: Color(0xFF0678D9),
  100: Color(0xFF0678D9),
  200: Color(0xFF0678D9),
  300: Color(0xFF0678D9),
  400: Color(0xFF0678D9),
  500: Color(0xFF0678D9),
  600: Color(0xFF0678D9),
  700: Color(0xFF0678D9),
  800: Color(0xFF0678D9),
  900: Color(0xFF0678D9),
});
